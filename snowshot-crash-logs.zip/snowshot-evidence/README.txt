Snow Shot 1.3.x 启动即崩（0xc0000005 @ ntdll）证据包 — DESKTOP-F3H7JHH, 2026-10-24
=====================================================================
1. 上游要的 %APPDATA%\SnowShotMini\snow_shot_mini\logs 与
   %LOCALAPPDATA%\SnowShotMini\snow_shot_mini\logs 两个目录**不存在**：
   mini 版崩在日志初始化之前，从未创建过这两个目录（全机 find 已核）。
2. app-logs/snow_shot-logs：%LOCALAPPDATA%\SnowShot\snow_shot\logs 全量
   （完整版 1.3.x 的 crashes 目录——reports/attachments 均空，崩溃早于自身 reporter 落盘）。
3. WER/：C:\ProgramData\Microsoft\Windows\WER\ReportArchive 下全部
   AppCrash_snow_shot.exe_*（13 份，完整版 1.3.0/1.3.6/1.3.8）与
   AppCrash_snow_shot_mini.e_*（1 份，mini 版）的 Report.wer。
4. 环境：Windows 11 Pro 25H2 build 26200.9457，RTX 4060 Ti 驱动 32.0.16.1060，
   GameViewer 虚拟显示并存。1.2.9（Qt 6.12.0）正常；1.3.x SHA256 与官方一致，
   无三方注入，兼容模式/QT 软渲染均无效。崩溃栈加载 d3d12/dxgi 时 AV。
